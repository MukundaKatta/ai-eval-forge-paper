# Preprint Package

This folder contains the second paper package built from the `ai-eval-forge` repository.

It is shaped for:

- Zenodo
- OSF Preprints
- SSRN
- later adaptation for a software-paper venue

Contents:

- `paper.md` for the manuscript
- `assets/workflow-figure.svg` for the manuscript figure
- `abstract.txt` for submission forms
- `author-bio.txt` for short researcher-profile fields
- `cover-note.txt` for preprint forms and repository context
- `keywords.txt`
- `paper.bib` for the current references
- `submission-metadata.json` for reusable metadata
- `zenodo-upload-checklist.md` for the first public posting route
- `render_preprint_pdf.py` to render a submission PDF locally
